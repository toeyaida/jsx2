export default class BMI{
  bmiCalculate(w,h,r){
    var a=w/h**2;
    if(r == 'asian'){
      if(a<=18.5){
        return 'Under weight';
      }
      if(a>18.5 && a<=24.9 ){
        return 'Normal weight';
      }
      if(a > 24.9 && a<=29.9){
        return 'Overweight';
      }
      if(a>29.9 ){
        return 'obesity';
      }
    }else{
      if(a<=19.5){
        return 'Under weight';
      }
      if(a>19.5 && a<=34.9 ){
        return 'Normal weight';
      }
      if(a>34.9 && a<=39.9){
        return 'Overweight';
      }
      if(a>39.9 ){
        return 'obesity';
      }
    }
  }
}